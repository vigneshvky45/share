package libraries;

import java.io.IOException;
import java.util.Base64;
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.relevantcodes.extentreports.LogStatus;

import repositories.IncidentsPage;
import repositories.LoginPage;
import supportLibraries.Driver;
import supportLibraries.MainScript;
import supportLibraries.ReusableLibrary;
import supportLibraries.ReusableMethods;
import supportLibraries.ScriptHelper;
import supportLibraries.SeleniumTestParameters;
import supportLibraries.WebDriverFactory;

public class Incident extends ReusableLibrary {

	private MainScript mainscript_obj= new MainScript(scriptHelper);

	public Incident(ScriptHelper scriptHelper) {
		super(scriptHelper);
	}
	/**
	 * DriverScript constructor
	 * 
	 * @param testParameters
	 *            A {@link SeleniumTestParameters} object
	 */


	String sheetname="Incident";
	public void create_new_incident() throws Exception {

		int EndOfSubIteration = Integer.parseInt(dataTable.getData(sheetname, "EndofSubIteration"));

		for (int currentSubIteration=1; currentSubIteration <= EndOfSubIteration; currentSubIteration++) {
			dataTable.setCurrentRow(1, currentSubIteration);
			//dataTable.setCurrentRow(1, 1);

			String operation=dataTable.getData(sheetname, "OPERATION");
			switch(operation) {

			case "Create_Incident":
				create_incident();
				break;
			case "LoginAsDifferentUser":
				loginasdiffuser();
				break;
			default:
				System.out.println("********Default*******");
				break;
			}
		}

		dataTable.setCurrentRow(1, 1);
	}



	private void create_incident() throws Exception {
		System.out.println("********Creating new incident*******");
		/*
		 * functionality changed so commenting
		 */
		/*String parent=driver.getWindowHandle();
		Set<String> child = driver.getWindowHandles();
		Iterator<String> iterator=child.iterator();
		while(iterator.hasNext()) {
			String child_window=iterator.next();
			if(!parent.equals(child_window)) {
				driver.switchTo().window(child_window);
				System.out.println(driver.switchTo().window(child_window).getTitle());
			}
		}*/

		ReusableMethods.click(IncidentsPage.add_incident);
		ReusableMethods.click(IncidentsPage.incident_type);
		String incident_type=dataTable.getData(sheetname, "IncidentType");
		IncidentsPage.set_incident_options(incident_type);
		ReusableMethods.click(IncidentsPage.incident_options);
		ReusableMethods.click(IncidentsPage.involved_person);
		String involved_persons=dataTable.getData(sheetname, "InvolvedPerson");
		String[] a1=involved_persons.split(";");
		for(int i=0;i<a1.length;i++) {
			IncidentsPage.set_incident_options(a1[i].trim());
			ReusableMethods.click(IncidentsPage.incident_options);
		}
		ReusableMethods.click(IncidentsPage.done);
		ReusableMethods.click(IncidentsPage.people_involved_count);
		ReusableMethods.enterData(IncidentsPage.people_involved_count, Integer.toString(a1.length));
		ReusableMethods.click(IncidentsPage.location);
		String location=dataTable.getData(sheetname, "Location");
		IncidentsPage.set_incident_options(location);
		ReusableMethods.click(IncidentsPage.incident_options);
		ReusableMethods.click(IncidentsPage.area);
		String area=dataTable.getData(sheetname, "Area");
		IncidentsPage.set_incident_options(area);
		ReusableMethods.click(IncidentsPage.incident_options);

		ReusableMethods.enterData(IncidentsPage.pin_location, dataTable.getData(sheetname, "Pin_Location"));
		/*ReusableMethods.click(IncidentsPage.map);
		String person_injured=dataTable.getData(sheetname, "Person_Injured");
		if(person_injured.equalsIgnoreCase("NO")) {
			ReusableMethods.click(IncidentsPage.person_injured_no);
		}else {
			ReusableMethods.click(IncidentsPage.person_injured_yes);
		}*/
		ReusableMethods.enterData(IncidentsPage.wat_happened, dataTable.getData(sheetname, "What_Happened"));

		/*String loc_status=dataTable.getData(sheetname, "Location_Status");
		if(loc_status.equalsIgnoreCase("NO")) {
			ReusableMethods.click(IncidentsPage.loc_status_no);
		}else {
			ReusableMethods.click(IncidentsPage.loc_status_yes);
		}

		String fire_dept=dataTable.getData(sheetname, "Fire_Department");
		if(fire_dept.equalsIgnoreCase("NO")) {
			ReusableMethods.click(IncidentsPage.fire_dept_no);
		}else {
			ReusableMethods.click(IncidentsPage.fire_dept_yes);
		}
		 */
		ReusableMethods.click(IncidentsPage.priority);
		String priority=dataTable.getData(sheetname, "Priority");
		IncidentsPage.set_incident_options(priority);
		ReusableMethods.click(IncidentsPage.incident_options);

		String doc_cons=dataTable.getData(sheetname, "Doc_Consulted");
		if(doc_cons.equalsIgnoreCase("NO")) {
			ReusableMethods.click(IncidentsPage.doc_consulted_no);
		}else {
			ReusableMethods.click(IncidentsPage.doc_consulted_yes);
		}
		String path=dataTable.getData(sheetname, "Injury_Image");
		ReusableMethods.click(IncidentsPage.injury_img);
		ReusableMethods.waitForLoad();
		ReusableMethods.upload(path);
		System.out.println("File uploaded successfully");
		//driver.findElement(IncidentsPage.injury_img).sendKeys(path);
		ReusableMethods.click(IncidentsPage.signature);
		ReusableMethods.draw_signature(IncidentsPage.sign_area);

		/*String add_on=dataTable.getData(sheetname, "Add_on");
		if(add_on.equalsIgnoreCase("NO")) {
			ReusableMethods.click(IncidentsPage.add_on_no);
		}else {
			ReusableMethods.click(IncidentsPage.add_on_no);
		}

		String add_on_one=dataTable.getData(sheetname, "Add_on_one");
		if(add_on_one.equalsIgnoreCase("NO")) {
			ReusableMethods.click(IncidentsPage.add_on_one_no);
		}else {
			ReusableMethods.click(IncidentsPage.add_on_one_yes);
		}
		 */

		ReusableMethods.click(IncidentsPage.save);
	}
	public void loginasdiffuser()throws Exception {
		driver.switchTo().defaultContent();
		ReusableMethods.click(LoginPage.account);
		ReusableMethods.click(LoginPage.signout);

		ReusableMethods.click(LoginPage.signin);
		ReusableMethods.click(LoginPage.microsoft);
		ReusableMethods.enterData(LoginPage.email, dataTable.getData(sheetname, "Email"));
		ReusableMethods.click(LoginPage.submit);
		String encodedpassword=dataTable.getData(sheetname, "EncodedPassword");
		byte[] decodedBytes = Base64.getDecoder().decode(encodedpassword.getBytes());
		ReusableMethods.enterData(LoginPage.password,new String(decodedBytes));
		ReusableMethods.click(LoginPage.submit);
		ReusableMethods.click(LoginPage.submit);
		/*String app_title=dataTable.getData(sheetname, "Title");
		LoginPage.set_app(app_title);
		ReusableMethods.click(LoginPage.app_tile);
		driver.switchTo().frame("SimulatorIFrame");
		ReusableMethods.waitForLoad();*/		
	}
}
