package libraries;

import java.io.IOException;
import java.util.Base64;

import repositories.LoginPage;
import supportLibraries.ReusableLibrary;
import supportLibraries.ReusableMethods;
import supportLibraries.ScriptHelper;

public class Login extends ReusableLibrary{

	public Login(ScriptHelper scriptHelper) {
		super(scriptHelper);
	}
	String sheetname="General_Data";
	public void logintoapplication() throws NumberFormatException, Exception {
		//int EndOfIteration = Integer.parseInt(dataTable.getData(sheetname, "EndofIteration"));

		//for (int currentIteration=1; currentIteration <= EndOfIteration; currentIteration++) {
		//dataTable.setCurrentRow(1, currentIteration);
		dataTable.setCurrentRow(1, 1);
		ReusableMethods.click(LoginPage.signin);
		ReusableMethods.click(LoginPage.microsoft);
		ReusableMethods.enterData(LoginPage.email, dataTable.getData(sheetname, "Email"));
		ReusableMethods.click(LoginPage.submit);
		String encodedpassword=dataTable.getData(sheetname, "EncodedPassword");
		byte[] decodedBytes = Base64.getDecoder().decode(encodedpassword.getBytes());
		ReusableMethods.enterData(LoginPage.password,new String(decodedBytes));
		ReusableMethods.click(LoginPage.submit);
		ReusableMethods.click(LoginPage.submit);
		String app_title=dataTable.getData(sheetname, "Title");
		LoginPage.set_app(app_title);
		ReusableMethods.click(LoginPage.app_tile);
		driver.switchTo().frame("SimulatorIFrame");
		ReusableMethods.waitForLoad();
		//}
		//dataTable.setCurrentRow(1, 1);
	}
}
