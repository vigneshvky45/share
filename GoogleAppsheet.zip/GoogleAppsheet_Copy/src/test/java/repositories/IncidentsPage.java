package repositories;

import org.openqa.selenium.By;

public class IncidentsPage {
	public static final By add_incident=By.xpath("//i[@class='fa far fa-plus']/../..");
	public static final By incident_type=By.xpath("//span[@class='ASTappable ListSelect__button ASTappable--pointer']");
	public static final By search=By.xpath("//span[contains(text(),'Search')]/../../../input");
	public static String incident_options;
	public static void set_incident_options(String option) {
		incident_options="//div[@class='ListSelectPopupOption__value']//span[contains(text(),'"+option+"')]/../../../..//div[@class='ListSelectPopupOption__icon']";
	}
	public static final By involved_person=By.xpath("//span[text()='Involved person name']/../..//span[@class='ASTappable ListSelect__button ASTappable--pointer']");
	public static final By location=By.xpath("//span[text()='Location']/../..//span[@class='ASTappable ListSelect__button ASTappable--pointer']");
	public static final By clear=By.xpath("//span[text()='Clear']");
	public static final By done=By.xpath("//span[text()='Done']");
	public static final By people_involved_count=By.xpath("//input[@aria-label='Count of people involved']");
	public static final By area=By.xpath("//span[text()='Area']/../..//span[@class='ASTappable ListSelect__button ASTappable--pointer']");
	
	public static final By pin_location=By.xpath("//input[@aria-label='Pin location of where the incident occurred']");
	public static final By map=By.xpath("//*[@id='__TableEntryScreenIncidents_SchemaNew_form_incident_sliceFloor_map_new']//div[@class='BaseCoordinateTypeInput__map-parent']//img");
	public static final By person_injured_no=By.xpath("(//span[text()='Is the person injured']/../..//span[@data-testid='button-select-button'])[1]");
	public static final By person_injured_yes=By.xpath("(//span[text()='Is the person injured']/../..//span[@data-testid='button-select-button'])[2]");
	public static final By wat_happened=By.xpath("//textarea[@aria-label='Describe what has happened']");
	public static final By loc_status_no=By.xpath("(//span[text()='Location status']/../..//span[@data-testid='button-select-button'])[1]");
	public static final By loc_status_yes=By.xpath("(//span[text()='Location status']/../..//span[@data-testid='button-select-button'])[2]");
	public static final By fire_dept_no=By.xpath("(//span[text()='Did the fire department informed']/../..//span[@data-testid='button-select-button'])[1]");
	public static final By fire_dept_yes=By.xpath("(//span[text()='Did the fire department informed']/../..//span[@data-testid='button-select-button'])[2]");
	public static final By priority=By.xpath("//span[text()='Priority']/../..//article[@class='ListSelect']/span");
	public static final By doc_consulted_no=By.xpath("(//span[text()='Doctor consulted']/../..//span[@data-testid='button-select-button'])[1]");
	public static final By doc_consulted_yes=By.xpath("(//span[text()='Doctor consulted']/../..//span[@data-testid='button-select-button'])[2]");
	public static final By signature=By.xpath("//span[text()='Tap to unlock']");
	public static final By sign_area=By.xpath("//canvas[@class='BaseScribbleTypeInput__canvas resizable']");
	public static final By sign_clear=By.xpath("//span[@class='ASTappable BaseScribbleTypeInput__clear--button iconContainer ASTappable--pointer    Tappable-tapped']/i");
	public static final By add_on_no=By.xpath("(//span[text()='Add on ( Yes no )']/../..//span[@data-testid='button-select-button'])[1]");
	public static final By add_on_yes=By.xpath("(//span[text()='Add on ( Yes no )']/../..//span[@data-testid='button-select-button'])[2]");
	public static final By add_on_one_no=By.xpath("(//span[text()='Add on ( Yes no ) one']/../..//span[@data-testid='button-select-button'])[1]");
	public static final By add_on_one_yes=By.xpath("(//span[text()='Add on ( Yes no ) one']/../..//span[@data-testid='button-select-button'])[2]");
	public static final By cancel=By.xpath("//span[@data-testid='footer-button-cancel']");
	public static final By save=By.xpath("//span[@data-testid='footer-button-save']");
	public static final By injury_img=By.xpath("//div[@class='PhotoInputControlBase BaseTypeInput']");
	
}	
