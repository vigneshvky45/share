package repositories;

import org.openqa.selenium.By;

public class LoginPage {
   public static final By signin=By.xpath("//*[@id='header']/div[2]//a[contains(text(),'Sign in')]");
   public static final By microsoft=By.xpath("//button[@id='Microsoft']");
   public static final By email=By.xpath("//input[@type='email']");
   public static final By submit=By.xpath("//input[@type='submit']");
   public static final By password=By.xpath("//input[@type='password']");
   public static final By account=By.xpath("//button[@aria-label='Account']");
   public static final By signout=By.xpath("//span[text()='Sign out']/..");
   public static String app_tile;
   
   public static void set_app(String value) {
	   //app_tile="//p[@title='"+value+"']/..";
	   app_tile=" //span[text()='"+value+"']/../..";
   }
}
